INSERT INTO `items` (name, label, weight, rare, can_remove) VALUES
	('marijuana', 'Marijuana', 1,1,1),
	('coke','coke',1,1,1),
	('cannabis','cannabis',1,1,1),
	('Opium','Opium',1,1,1),
	('coke_pooch','coke pooch',1,1,1),
	('amfe','Amfetamine',1,1,1),
	('amfe_pooch','amfetamine pooch')
;
