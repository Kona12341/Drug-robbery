This is Drug Robbery for fivem !
First of all you need cayo perico Then you need "esx_policejob" and "progressBars"!
all you have to is drag and drop and write "start esx_drugRobbery" in server.cfg and dont forget SQL its very important!
If you want to say something to me add me in discord Bubsi#6775



Original script = https://github.com/esx-community/esx_vangelico_robbery

Preview video = https://youtu.be/7eQYTG_Ow6A!
Locations = ![locations](https://user-images.githubusercontent.com/95187459/165084988-6add736e-8de5-4044-8225-db38ba1fc7b8.jpg)



Sry for bad english i hope you understand my english :)
